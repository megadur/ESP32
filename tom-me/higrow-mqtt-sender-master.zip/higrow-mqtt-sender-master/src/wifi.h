#ifndef WIFI_H
#define WIFI_H

boolean connect_wifi();

#endif
