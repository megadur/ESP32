#ifndef DEVICE_ID_H
#define DEVICE_ID_H

String get_device_id();

#endif
